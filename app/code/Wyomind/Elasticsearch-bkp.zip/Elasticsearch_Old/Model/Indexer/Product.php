<?php



/**     
 * The technical support is guaranteed for all modules proposed by Wyomind.
 * The below code is obfuscated in order to protect the module's copyright as well as the integrity of the license and of the source code.
 * The support cannot apply if modifications have been made to the original source code (https://www.wyomind.com/terms-and-conditions.html).
 * Nonetheless, Wyomind remains available to answer any question you might have and find the solutions adapted to your needs.
 * Feel free to contact our technical team from your Wyomind account in My account > My tickets. 
 * Copyright © 2018 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */
namespace Wyomind\Elasticsearch\Model\Indexer;

use Magento\Catalog\Model\Product\Attribute\Source\Status as ProductStatus;
use Magento\Customer\Model\Group as CustomerGroup;
use Magento\UrlRewrite\Controller\Adminhtml\Url\Rewrite as UrlRewrite;
use Wyomind\Elasticsearch\Helper\Interfaces\CategoryInterface as CategoryHelperInterface;
use Wyomind\Elasticsearch\Helper\Interfaces\IndexerInterface as IndexerHelperInterface;
use Wyomind\Elasticsearch\Model\Request\DimensionFactory;
use Magento\Catalog\Helper\Data as CatalogHelper;
use Magento\CatalogSearch\Model\Indexer\IndexerHandlerFactory;
use Magento\Eav\Model\Config as EavConfig;
use Magento\Eav\Model\EntityFactory;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Event\ManagerInterface as EventManagerInterface;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Tax\Helper\Data as TaxHelper;


class Product extends AbstractIndexer
{public $xbd=null;public $xc2=null;public $x1c=null;

    
    protected $attributesChunkSize = 25;

    
    protected $productsChunkSize = 500;
    protected $coreHelper = null;
    protected $messageManager = null;
    public $error = "\105las\164ics\145\x61r\143\x68\x20Ind\145x \72\x20Inv\x61\154i\x64 L\151ce\x6e\x73\145\x21";
    protected $_categoryId = null;

    public function __construct(
    $type,
        ObjectManagerInterface $objectManager,
        IndexerHandlerFactory $indexerHandlerFactory,
        IndexerHelperInterface $indexerHelper,
        CategoryHelperInterface $categoryHelper,
        StoreManagerInterface $storeManager,
        DimensionFactory $dimensionFactory,
        EntityFactory $entityFactory,
        EavConfig $eavConfig,
        ResourceConnection $resource,
        TaxHelper $taxHelper,
        CatalogHelper $catalogHelper,
        EventManagerInterface $eventManager,
        PriceCurrencyInterface $priceCurrency,
        \Symfony\Component\Console\Output\ConsoleOutputFactory $consoleOutputFactory,
        \Wyomind\Core\Helper\Data $coreHelper,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        array $data = []
    )
    {

        parent::__construct($type, $objectManager, $indexerHandlerFactory, $indexerHelper, $categoryHelper, $storeManager, $dimensionFactory, $entityFactory, $eavConfig, $resource, $taxHelper, $catalogHelper, $eventManager, $priceCurrency, $consoleOutputFactory, $data);
        $coreHelper->constructor($this, func_get_args());
        $this->{$this->x1c->x806->{$this->xbd->x806->x829}} = $coreHelper;
        $this->{$this->xbd->x806->{$this->x1c->x806->x837}} = $messageManager;
    }

    
    public function executeFull()
    {
        parent::{$this->xc2->x806->xe4f}();

                $this->eventManager->{$this->xbd->x806->xe5a}(
            "\167y\157mi\156\144_\x65\154a\163\164\151\143\163e\x61\x72\x63h\x5f\146ull\x5f\x70\x72\x6f\144u\x63\x74\137r\145\x69n\144\145\170\x5f\x61\x66t\145r", ["i\156dex\145\162" => $this]
        );
    }

    public function setCategoryId($xc8)
    {
        $this->{$this->xbd->x806->{$this->xc2->x806->{$this->xc2->x806->{$this->xc2->x806->x857}}}} = ${$this->xbd->x80e->x17b3};
    }

    
    public function export(
    $x771,
        $x776 = []
    )
    {$xdd = $this->xbd->x806->{$this->x1c->x806->{$this->xbd->x806->{$this->xc2->x806->xcbf}}};$xe6 = $this->x1c->x80e->{$this->xbd->x80e->{$this->x1c->x80e->{$this->xbd->x80e->{$this->xc2->x80e->x1bda}}}};$x148 = $this->x1c->x80e->{$this->x1c->x80e->x1be3};$x123 = $this->xc2->x80e->{$this->x1c->x80e->x1bf2};$x6ea = $this->xc2->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->xd01}}};$x6c2 = $this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xd12}};$x535 = $this->xc2->x80e->x1c14;$x21c = $this->x1c->x806->{$this->xbd->x806->{$this->x1c->x806->xd2c}};$x76b = $this->x1c->x80e->{$this->xc2->x80e->{$this->x1c->x80e->{$this->xbd->x80e->x1c30}}};$x482 = $this->x1c->x80e->x1c35;$x356 = $this->x1c->x80e->x1c46;$x606 = $this->xc2->x806->xd6a;$x37b = $this->x1c->x806->{$this->x1c->x806->xd7e};$x3e5 = $this->xbd->x806->{$this->xbd->x806->{$this->xc2->x806->xd8c}};$x3f5 = $this->xc2->x80e->{$this->xbd->x80e->x1c77};$x534 = $this->xbd->x80e->x1c88;$x597 = $this->xbd->x80e->{$this->xbd->x80e->x1c91};$x5f0 = $this->xc2->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x1ca5}};$x63b = $this->x1c->x80e->{$this->xc2->x80e->x1cb1};$x658 = $this->x1c->x806->{$this->x1c->x806->xde9};$x70e = $this->x1c->x806->{$this->xc2->x806->{$this->x1c->x806->xdfc}};

        $this->{$this->x1c->x806->xe6a}("");
        $this->{$this->x1c->x806->xe6a}("\74\x63\x6f\155men\164\76\x49n\144e\170i\156\x67\x20\160\162\x6f\144u\143\x74\163\x20\x66\157\162\40s\164\157\162\x65\40\x69\144\x3a\40" . ${$this->x1c->x806->{$this->xbd->x806->{$this->xbd->x806->x901}}} . "\74\57c\157m\x6de\x6et\x3e");
        $this->eventManager->{$this->xbd->x806->xe5a}('wyomind_elasticsearch_product_export_before', ['store_id' => ${$this->xc2->x80e->x17bd}, 'ids' => ${$this->xbd->x80e->x17c5}]);
        try {
            $xdd(0); 

            ${$this->xc2->x80e->{$this->xc2->x80e->x17ce}} = $this->resource->{$this->xbd->x806->xe8f}('catalog_category_product_index');
            if ($xe6("\\M\x61\147\x65n\x74\157\\\103\141\x74\x61lo\x67\\\115ode\154\\\111n\x64\x65xe\162\\\103\x61\164\x65\147\157\162\x79\\\120\x72\x6f\x64uc\x74\\T\141\x62\x6ceM\x61i\x6e\164\141\151\156\145\x72") && ${$this->xbd->x806->{$this->xbd->x806->x91b}} = $this->objectManager->{$this->x1c->x806->xe99}("\\M\141\147\x65nt\157\\\x43\141t\141\154\157\x67\\M\157del\\\111nd\145x\x65r\\\x43a\164\145g\157\x72\171\\\120r\157\x64\x75c\x74\\T\141b\x6c\x65\x4da\x69\x6e\164ainer")) {
                ${$this->xbd->x80e->{$this->x1c->x80e->x17dc}} = ${$this->xbd->x806->x918}->{$this->x1c->x806->xea2}(${$this->xc2->x80e->x17bd});
                ${$this->x1c->x806->x911} = $this->resource->{$this->xbd->x806->xe8f}(${$this->xbd->x80e->{$this->x1c->x80e->x17dc}});
            }

            
            ${$this->x1c->x80e->x17e5} = $this->storeManager->{$this->xbd->x806->xeb4}(${$this->x1c->x806->{$this->xbd->x806->{$this->xbd->x806->x901}}});
            ${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->x17ed}}} = $this->{$this->xc2->x806->xec0}(\Magento\Catalog\Model\Product::ENTITY);
            ${$this->xbd->x806->{$this->xc2->x806->x945}} = ${$this->xc2->x806->{$this->xc2->x806->x936}}->{$this->xbd->x806->xecc}()->{$this->x1c->x806->xee0}();
            ${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x1806}}} = $this->resource->{$this->xbd->x806->xe8f}("c\141t\141\154o\x67\x5fp\x72\157\144\165\143t\x5f\145\156t\x69\x74y");
            ${$this->x1c->x80e->x1808} = $this->resource->{$this->x1c->x806->xefb}();
            ${$this->xbd->x806->{$this->xc2->x806->{$this->xbd->x806->x95f}}}->{$this->x1c->x806->xf05}("S\105T\40\123\x45\x53\x53\111\x4fN gr\x6f\165\x70_c\157\156cat\x5f\155a\170\137le\x6e\x20=\40\61\x30\x30\x30\x30;");
            ${$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x181c}}}}} = $this->categoryHelper->{$this->xbd->x806->xf0e}(${$this->xc2->x80e->x17bd});
            ${$this->x1c->x80e->{$this->x1c->x80e->{$this->x1c->x80e->x1826}}} = CustomerGroup::NOT_LOGGED_IN_ID;

            ${$this->xc2->x80e->x1827} = $this;
            ${$this->xbd->x80e->{$this->xc2->x80e->x1839}} = $x148($x123());
            $this->${$this->xbd->x80e->{$this->xc2->x80e->x1839}} = "";
            ${$this->xc2->x80e->x1842} = "\145rr\x6fr";
            ${$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->{$this->xc2->x806->x995}}}} = "\\\x4d\141ge\x6et\x6f\\Fr\141\155\145\167\157r\153\\\x45\170\143e\160ti\x6f\x6e\\\x4coc\x61l\151\x7a\x65\144\x45\170\x63\x65\x70ti\157\156";
            ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->x976}}}->coreHelper->{$this->xbd->x806->xe37}(${$this->x1c->x806->{$this->xbd->x806->x973}}, ${$this->xc2->x806->{$this->xc2->x806->x980}});
            ${$this->x1c->x80e->x1854} = new ${$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->{$this->xc2->x806->x995}}}}(__(${$this->xc2->x80e->{$this->x1c->x80e->x182b}}->${$this->x1c->x806->x989}));

            if (${$this->xc2->x80e->x1827}->${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->x183e}}} != $x148(${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->x183e}}})) {
                throw ${$this->xbd->x806->x999};
            }

            ${$this->x1c->x806->{$this->x1c->x806->x9a9}} = $this->{$this->x1c->x806->{$this->xbd->x806->x829}}->{$this->xc2->x806->xf26}("\115\x61gen\164\x6f\x5fE\x6et\x65\x72\x70\x72\x69\163\145") ? "\162ow\x5f\151\144" : "\x65n\164it\171\x5f\x69\144";

            if (empty(${$this->xbd->x80e->{$this->x1c->x80e->x17c9}})) {
                                ${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x186f}}}}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->x964}}}}->{$this->x1c->x806->xf2d}()->{$this->xc2->x806->xf3e}(["\145" => ${$this->xbd->x80e->{$this->xbd->x80e->{$this->x1c->x80e->{$this->x1c->x80e->x1807}}}}], "e\x6e\x74\151\164\171\137\151\144");

                                ${$this->xbd->x806->x9b5}->join(
                    ["\x70r\x6fdu\143\164_\x77ebs\151t\x65" => $this->resource->{$this->xbd->x806->xe8f}("\x63a\x74\141\x6co\x67\137\x70ro\144\x75\143t\137\167\145\142\163\x69te")], "\x70ro\x64\165\x63t_\x77ebs\x69te.pr\157\x64u\x63t\x5fi\144\40\x3d \x65\x2e\x65\x6et\x69t\x79\x5f\151\x64 \x41N\x44 " . ${$this->x1c->x80e->x1808}->{$this->xc2->x806->xf55}("pr\157\144u\143\164_\167\x65\142\x73\151\x74\145\56\x77\145\142\163\x69\164\145_\151\144 \75 ?", ${$this->xc2->x806->x92d}->{$this->x1c->x806->xf5c}()), []
                );

                                if (!$this->indexerHelper->{$this->xc2->x806->xf65}(${$this->x1c->x80e->x17e5})) {
                    ${$this->x1c->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xbd->x806->x9c4}}}} = $this->indexerHelper->{$this->xbd->x806->xf75}(${$this->x1c->x80e->x17e5});
                    ${$this->xc2->x80e->{$this->xc2->x80e->{$this->x1c->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x1888}}}}} = [
                        "\163\x74\157\x63k.\165s\x65_\143o\x6e\x66\151\147\137m\x61\x6e\141ge\x5f\163\164\x6fc\x6b =\40\x30 \101N\104\x20\x73\164\157\x63\x6b\56\x6d\x61na\147e\x5f\163\164o\143\153\x20\x3d \61\x20\x41N\x44\40st\157\143k\56\x69\163_\x69\x6e\x5f\x73t\x6fck\x20\75\40\61",
                        "st\x6f\x63k\x2e\165\x73e_co\156\x66\x69\x67_\x6da\156\141g\145_s\164\157ck \x3d \x30 \x41N\104\40\163t\x6f\x63\153\x2e\155\141\x6ea\x67\145_st\157\x63\153\40=\x20\x30",
                    ];
                    if (${$this->x1c->x806->{$this->x1c->x806->x9c0}}) {
                        ${$this->xc2->x80e->{$this->xc2->x80e->{$this->x1c->x80e->x1882}}}[] = "s\x74\157c\153\56\x75\x73e\x5f\143o\156\146\151g\137\155\x61\x6e\x61ge\137\x73\164\x6f\x63\153\x20=\40\61\40\x41\x4e\x44\40\163\x74\157\143\153\x2eis_i\156\x5fs\164\x6fc\153 = \61";
                    } else {
                        ${$this->xc2->x80e->{$this->xc2->x80e->{$this->x1c->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x1888}}}}}[] = "\x73\x74\x6fc\153\56\x75se\137\x63on\146\151\x67\137\155a\x6ea\x67\x65\137\x73to\x63k\40= \61";
                    }
                    ${$this->xc2->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x1893}}} = "\x28(" . $x6c2("\x29\40OR\40\x28", ${$this->xbd->x806->x9c6}) . "\51\x29";
                    ${$this->xbd->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x186b}}}->join(
                        ["s\x74o\143\x6b" => $this->resource->{$this->xbd->x806->xe8f}("\x63\x61\164\x61l\157\x67\151nv\x65ntor\171\x5f\163\x74\x6fc\153\x5f\x69\164e\x6d")], "(s\164\x6f\x63k\56\x70\162\x6f\144\x75c\164\137i\x64\x20\75 \145\x2ee\156t\151t\x79_i\144)\40\x41N\104 " . ${$this->xbd->x80e->x188c}, []
                    );
                }

                                ${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x18a0}}}} = ${$this->xbd->x80e->{$this->x1c->x80e->x17ec}}->{$this->xbd->x806->xf94}("s\x74a\164\165\x73")->{$this->xbd->x806->xfa2}();
                if (${$this->xc2->x80e->x1898}) {
                    ${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->x186e}}}}->join(
                        ["\163t\141\x74u\163" => $this->resource->{$this->xbd->x806->xe8f}("cata\x6c\157\147_\160\x72o\144\165ct\137\x65\156t\x69\x74\171\137\151\x6e\x74")], "\163\164\x61\164us\56\141\164t\x72\x69\142\165\x74\x65\x5fid \x3d\x20" . ${$this->xbd->x80e->{$this->x1c->x80e->x189c}} . " \x41N\x44 \163\164atus\56" . ${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->x1864}}} . " =\40\145\56" . ${$this->xbd->x80e->{$this->xbd->x80e->x1861}}, []
                    );
                    ${$this->xbd->x80e->{$this->xc2->x80e->x18a7}} = ProductStatus::STATUS_ENABLED;
                    ${$this->xbd->x806->x9b5}->{$this->x1c->x806->xfb8}("\163t\x61\164\165\x73\56\166\x61\x6c\165\145 =\x20\x3f", ${$this->xc2->x806->x9de});
                    ${$this->xbd->x806->x9b5}->{$this->x1c->x806->xfb8}("\x73\x74a\164us\56\163\164\x6f\x72\x65\x5fid\40\x49\x4e (?)", [0, ${$this->xc2->x80e->x17bd}]);
                }

                                ${$this->x1c->x806->{$this->xbd->x806->{$this->xbd->x806->x90e}}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->x964}}}}->{$this->xc2->x806->xfd0}(${$this->xbd->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x186b}}});
                ${$this->xbd->x806->x904} = $x535(${$this->xbd->x80e->{$this->x1c->x80e->x17c9}});
            }

                        ${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x18bc}}}} = $x21c(${$this->xbd->x806->x904}, $this->{$this->xbd->x80e->x16e9});

            ${$this->x1c->x806->x9f5} = $x76b(${$this->xbd->x806->{$this->x1c->x806->x9ed}});
            ${$this->xc2->x80e->{$this->x1c->x80e->x18cc}} = 1;

            $this->{$this->x1c->x806->xe6a}("<\x69n\146\157\x3e" . $x76b(${$this->xbd->x80e->x17c5}) . " \160r\157\x64\165c\164\x73\40\146\x6f\165nd\x3c\x2f\151n\x66\157\x3e");
            $this->{$this->x1c->x806->xe6a}("\74\x69n\146o\x3e\x53\x70li\164 \151n\x74\157\40" . ${$this->xbd->x80e->x18be} . "\x20c\150\165n\x6b\163 f\157r\x20\142\x65\x74\x74e\x72\40p\145\x72for\155e\x6e\x63\x65\74\x2f\x69\x6e\146o\x3e");
            foreach (${$this->xbd->x806->x9e8} as ${$this->x1c->x80e->x18cf} => ${$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x18e5}}}}) {

                $this->{$this->x1c->x806->xe6a}("" . (${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->xa07}}}++) . "\57" . ${$this->x1c->x80e->{$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18c7}}}}});

                                ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}} = [];
                ${$this->xbd->x80e->{$this->xc2->x80e->x18f3}} = [];
                foreach (${$this->xbd->x806->{$this->xc2->x806->x945}} as ${$this->xc2->x806->{$this->x1c->x806->xa2f}} => ${$this->x1c->x806->{$this->xbd->x806->{$this->xc2->x806->{$this->xc2->x806->{$this->x1c->x806->xa43}}}}}) {
                    ${$this->x1c->x806->{$this->xbd->x806->{$this->xbd->x806->xa3c}}} = $x21c(${$this->x1c->x806->{$this->xbd->x806->{$this->xc2->x806->{$this->xc2->x806->{$this->x1c->x806->xa43}}}}}, $this->{$this->xbd->x80e->x16e1});
                    foreach (${$this->x1c->x80e->x1907} as ${$this->xc2->x80e->{$this->x1c->x80e->{$this->xbd->x80e->x1914}}}) {
                        ${$this->xbd->x80e->{$this->x1c->x80e->x1869}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->x967}}}}}->{$this->x1c->x806->xf2d}()
                            ->{$this->xc2->x806->xf3e}(["e" => ${$this->xc2->x806->x957}], ["\151\x64" => "\x65\156\164\x69ty_\151d", "sku", "\x74\171p\x65\x5f\x69\144"]);

                        foreach (${$this->xc2->x80e->{$this->xbd->x80e->x1911}} as ${$this->xc2->x80e->x1917}) {

                            
                            if (!$this->indexerHelper->{$this->xc2->x806->x102a}(${$this->xbd->x806->xa54})) {
                                continue;
                            }

                            ${$this->x1c->x806->{$this->xbd->x806->x9dd}} = ${$this->x1c->x806->{$this->xc2->x806->xa55}}->{$this->xc2->x806->x1033}();
                            ${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x1929}}} = ${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x191d}}}->{$this->xbd->x806->x1041}();

                            if (!isset(${$this->xbd->x80e->{$this->x1c->x80e->{$this->xbd->x80e->{$this->xc2->x80e->x18fa}}}}[${$this->x1c->x80e->{$this->xbd->x80e->x1925}}]) && $this->indexerHelper->{$this->x1c->x806->x104a}(${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x191d}}})) {
                                ${$this->x1c->x806->{$this->x1c->x806->xa5e}} = ${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x191d}}}->{$this->xbd->x806->x104f}(${$this->xbd->x806->x8fc})
                                    ->{$this->x1c->x806->x1058}()
                                    ->{$this->x1c->x806->x106b}();
                                foreach (${$this->x1c->x806->xa5d} as ${$this->x1c->x806->{$this->xbd->x806->{$this->xbd->x806->xa65}}}) {
                                    if (!${$this->x1c->x806->{$this->xc2->x806->xa63}}["v\x61l\x75\x65"]) {
                                        continue;
                                    }
                                    ${$this->xbd->x80e->{$this->xc2->x80e->x18f3}}[${$this->x1c->x806->xa58}][${$this->xc2->x806->xa5f}["\x76\141l\x75e"]] = ${$this->xc2->x806->xa5f}["\154\141\142\145l"];
                                }
                            }

                            ${$this->x1c->x80e->{$this->xbd->x80e->x1935}} = ${$this->xbd->x80e->x1921} . "\137d\x65\146\x61\x75\154\x74";
                            ${$this->xbd->x80e->{$this->x1c->x80e->x1869}}->{$this->x1c->x806->x1074}(
                                [${$this->x1c->x80e->{$this->xbd->x80e->x1935}} => $this->resource->{$this->xbd->x806->xe8f}(${$this->xbd->x806->xa2b})], ${$this->x1c->x80e->x1933} . ".\x61t\164\162i\142u\164e\137i\x64\x20\x3d " . ${$this->xbd->x80e->{$this->x1c->x80e->{$this->x1c->x80e->x189d}}} . "\x20\x41\116D\40" . ${$this->x1c->x80e->{$this->xbd->x80e->x1935}} . "\x2e" . ${$this->xc2->x80e->x185e} . "\40\x3d\x20\x65\x2e" . ${$this->xc2->x80e->x185e} . "\x20\101\116\104 " . ${$this->x1c->x806->xa6c} . "\x2esto\162\145\x5f\151d \75 \x30", []
                            );
                            ${$this->xbd->x806->{$this->xbd->x806->{$this->x1c->x806->xa77}}} = ${$this->x1c->x80e->{$this->xbd->x80e->x1925}} . "_s\164o\162\x65";
                            ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->{$this->x1c->x80e->x194a}}}}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->x967}}}}}->{$this->x1c->x806->x1095}(${$this->xbd->x806->{$this->xbd->x806->xa75}} . "\x2e\166\x61lue I\x53 \116U\x4c\x4c", ${$this->x1c->x806->xa6c} . ".v\x61\x6cu\145", ${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x1940}}}} . "\56\x76\141\x6cu\145");
                            ${$this->xbd->x806->x9b5}->{$this->x1c->x806->x1074}(
                                [${$this->x1c->x80e->x1937} => $this->resource->{$this->xbd->x806->xe8f}(${$this->xc2->x80e->{$this->x1c->x80e->{$this->xc2->x80e->x1902}}})], ${$this->xbd->x806->{$this->xbd->x806->{$this->x1c->x806->xa77}}} . ".\x61\x74t\x72\x69\142\x75t\x65\x5f\x69\144\x20=\x20" . ${$this->xc2->x80e->x1898} . "\x20AN\x44\40" . ${$this->xc2->x806->xa70} . "\56" . ${$this->x1c->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->x9ae}}}} . " \x3d\40\145\x2e" . ${$this->xbd->x80e->{$this->xbd->x80e->x1861}} . "\x20\x41ND\x20" . ${$this->xc2->x806->xa70} . "\56\163to\162e\x5fid\40\x3d " . ${$this->xbd->x806->{$this->x1c->x806->x92e}}->{$this->xbd->x806->xfa2}(), [${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x1929}}} => ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->{$this->x1c->x80e->x194a}}}}}]
                            );
                        }

                        ${$this->xbd->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x186b}}}->{$this->x1c->x806->xfb8}("\x65\56\x65nt\151\164y\137\151d\40\111\x4e\40\x28?\x29", ${$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x18e5}}}});

                        ${$this->xbd->x806->{$this->xc2->x806->xa8c}} = ${$this->xc2->x80e->{$this->xbd->x80e->x180b}}->{$this->x1c->x806->xf05}(${$this->xbd->x806->x9b5});
                        while (${$this->x1c->x806->{$this->xbd->x806->xa93}} = ${$this->xc2->x80e->x194d}->{$this->x1c->x806->x10e2}()) {
                            ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa99}}}} = $x482(${$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa94}}}, "\163t\x72\154\145\156");
                            ${$this->xc2->x80e->{$this->xbd->x80e->x1953}}["\151\144"] = (int) ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}}["\x69d"];
                            ${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->xaa9}}}} = ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa99}}}}["\151\x64"];
                            if (!isset(${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->xc2->x80e->x1963}}}}}])) {
                                ${$this->x1c->x80e->{$this->xbd->x80e->x18ec}}[${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->xaa9}}}}] = [];
                            }
                            foreach (${$this->xbd->x806->xa91} as ${$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xaba}}} => &${$this->x1c->x80e->x196d}) {
                                if (isset(${$this->x1c->x806->x942}[${$this->xc2->x80e->{$this->xc2->x80e->x1900}}][${$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xc2->x806->xabf}}}}])) {
                                    ${$this->x1c->x806->xac3} = $this->indexerHelper->{$this->xc2->x806->x10eb}(${$this->xbd->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x17fd}}}[${$this->xc2->x806->{$this->x1c->x806->xa2f}}][${$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xc2->x806->xabf}}}}], ${$this->x1c->x806->{$this->xc2->x806->xac6}}, ${$this->xc2->x80e->{$this->xbd->x80e->x17e9}});
                                }
                                if (isset(${$this->xbd->x806->{$this->xbd->x806->{$this->xc2->x806->xa21}}}[${$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xc2->x806->xabf}}}}])) {
                                                                        ${$this->xc2->x806->{$this->x1c->x806->xad1}} = [];
                                    ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x198c}}} = "/\x28\x5b\x30\55\71]\x2b\x29\x2c \77\57";
                                    $x356(${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x1991}}}}, ${$this->x1c->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xacd}}}}, ${$this->xbd->x806->xace});
                                    if (!empty(${$this->xc2->x806->{$this->x1c->x806->xad1}}[1])) {
                                        ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa99}}}}[${$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xaba}}} . "_\151\x64\x73"] = $x606(',', ${$this->xc2->x80e->{$this->xc2->x80e->x196e}});
                                        ${$this->x1c->x806->xac3} = $x606(',', ${$this->x1c->x80e->x196d});
                                    } else {
                                        ${$this->xc2->x806->{$this->x1c->x806->xad1}} = [];
                                        ${$this->x1c->x806->{$this->xbd->x806->xadc}} = "\x2f\50[\x30\55\71\x5d+\51\77\x2f";
                                        $x356(${$this->xc2->x80e->x1983}, ${$this->xc2->x80e->{$this->xc2->x80e->x196e}}, ${$this->xc2->x806->{$this->x1c->x806->xad1}});
                                        if (!empty(${$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->xad5}}}[1])) {
                                            ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa99}}}}[${$this->xbd->x80e->x1964} . "_\151\x64s"] = ${$this->x1c->x80e->x196d};
                                            ${$this->x1c->x80e->x196d} = $x606(',', ${$this->x1c->x806->{$this->xc2->x806->xac6}});
                                        }
                                    }
                                    if ($x37b(${$this->x1c->x806->{$this->xbd->x806->{$this->xc2->x806->xacb}}})) {
                                        ${$this->xc2->x806->{$this->x1c->x806->xadf}} = [];
                                        foreach (${$this->x1c->x806->{$this->xbd->x806->{$this->xc2->x806->xacb}}} as ${$this->x1c->x80e->{$this->x1c->x80e->x19a9}}) {
                                            if (isset(${$this->xbd->x80e->{$this->x1c->x80e->{$this->x1c->x80e->x18f6}}}[${$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xaba}}}][${$this->xbd->x806->xaea}])) {
                                                ${$this->xc2->x806->xade}[] = ${$this->xc2->x80e->x18f0}[${$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xaba}}}][${$this->x1c->x80e->{$this->x1c->x80e->x19a9}}];
                                            }
                                        }
                                        if (!empty(${$this->xc2->x806->{$this->xc2->x806->{$this->xbd->x806->{$this->xc2->x806->xae7}}}})) {
                                            ${$this->xbd->x80e->x1952}[${$this->xc2->x80e->{$this->xbd->x80e->x1966}}] = ${$this->xc2->x806->{$this->x1c->x806->xadf}};
                                        }
                                    } elseif (isset(${$this->xbd->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xa24}}}}[${$this->xbd->x806->{$this->x1c->x806->xab8}}][${$this->x1c->x806->{$this->xbd->x806->{$this->xc2->x806->xacb}}}])) {
                                        ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}}[${$this->xc2->x80e->{$this->xbd->x80e->{$this->xc2->x80e->x196b}}}] = ${$this->xbd->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa29}}}}}[${$this->xbd->x806->xab3}][${$this->x1c->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xacd}}}}];
                                    }
                                }
                                if (${$this->xbd->x806->{$this->x1c->x806->xab8}} == "sk\x75") {
                                    ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}}[${$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xaba}}}] = $x3e5(${$this->xbd->x80e->x1952}[${$this->xc2->x80e->{$this->xbd->x80e->x1966}}]);
                                    ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}}[\Wyomind\Elasticsearch\Helper\Config::SKU_SUGGESTER] = $x3e5(${$this->xc2->x80e->{$this->xbd->x80e->x1953}}[${$this->xbd->x806->xab3}]);
                                }
                                if (${$this->xbd->x806->{$this->x1c->x806->xab8}} == "n\141\x6de") {
                                    ${$this->xbd->x806->xa91}[\Wyomind\Elasticsearch\Helper\Config::NAME_SUGGESTER] = $x3e5(${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}}[${$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xaba}}}]);
                                }
                            }
                            unset(${$this->x1c->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xacd}}}});


                            ${$this->xc2->x80e->x18e8}[${$this->xc2->x806->{$this->xc2->x806->xaa3}}] = $x3f5(${$this->x1c->x80e->{$this->xbd->x80e->x18ec}}[${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x1962}}}}], ${$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa94}}});
                        }
                    }
                }



                                ${$this->xc2->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x19b8}}} = [
                    "\160\x72\157\144uc\164\137i\x64" => "pro\144uct\137\151d",
                    "\143\141\164egor\171_\x69\144\x73" => new \Zend_Db_Expr(
                        "\124RI\115\50\12 \40\40 \40\x20\40\x20\x20\x20 \40 \x20 \40  \40 \x20\x20\x20 \40\40\40\x20 \x20  B\x4fT\x48\x20\x27\54\47\x20\x46\x52\x4f\x4d CON\x43\101T\x28\12\40 \x20\x20\x20\x20\40 \x20\40   \x20\x20\x20\40\40\x20\40 \x20\40\40\x20\x20\40 \x20 \40 \124\122\x49\115(B\x4fT\x48\x20',\x27 \x46R\117\x4d\40\x47\122O\125P\x5f\x43\117\116\x43\x41\x54\50I\106\x28\151\x73\137\160\141\162\145\156t\40\75 \x30, \x63a\164\x65\x67\157\x72\171\x5fi\144\x2c \x27'\51\x20\123EPA\x52\101\x54\117\x52 \x27,\47\x29\x29\x2c
\x20\40\x20\40 \x20\x20\x20\x20\x20\x20\x20\40\40\40\x20\x20\40\x20   \x20\40\x20\x20 \x20\x20\x20\x20\x20\40\x27\54\47\54\12 \40\40\x20 \x20\40\x20\x20 \40\40\40\40\40  \40       \40\x20\40 \40 \40\x20\124\122I\115\x28\x42\117\x54H\x20'\x2c\47\40F\x52\x4fM G\122OUP\x5f\x43\117\116\x43\x41T\50I\106(\x69\163\137\x70\x61\162e\156\x74\40\x3d\x20\61\54\x20\x63\141\164e\147\157\x72\171\x5f\151\144\x2c\x20\x27\x27) \x53\x45\120\x41\122A\x54O\x52\40\x27\x2c\x27\x29\x29
 \x20\x20\x20\x20 \40 \40\40\x20\40  \x20 \x20\40\x20\40\40\x20\40\40   \x20 \x20\x20 \x29\12\x20\40\x20\40\40\40\x20\40  \40\x20\40\40 \40\x20\40  \x20 \40 \x20\40\x20\x20\x20\40\40\x20)"
                    ),
                ];

                                ${$this->xc2->x80e->x19bd} = \Wyomind\Elasticsearch\Helper\Config::PRODUCT_PARENT_IDS;

                if ($this->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->x82b}}}->{$this->xc2->x806->xf26}("\115\x61\147e\x6e\164\x6f\x5fEn\x74\145r\160\x72\151s\x65")) {
                    ${$this->xbd->x806->x9b5} = ${$this->x1c->x80e->x1808}->{$this->x1c->x806->xf2d}()
                        ->{$this->xc2->x806->xf3e}($this->resource->{$this->xbd->x806->xe8f}("\x63\141t\x61l\x6fg_\x70\162\157\144\165\x63\x74_\162\145\x6c\141\x74\x69o\x6e"), ["c\x68i\154\x64_\151\x64"])
                        ->{$this->x1c->x806->x1074}(["\x63\x70\145" => $this->resource->{$this->xbd->x806->xe8f}("\x63\x61\x74a\154o\147_\160r\x6f\x64\x75\143\x74_e\156\164i\x74y")], "\143pe\56\x72\x6fw\137id\40\x3d pa\x72e\x6e\x74_\x69\144", ["\x70\141\x72en\164_i\144" => "\143p\145.e\156t\x69\164\171_\151\144"])
                        ->{$this->x1c->x806->xfb8}("c\x68i\154\144_\x69\144\x20\111N\x20\50?)", ${$this->xbd->x806->{$this->xbd->x806->{$this->xc2->x806->xa13}}});
                } else {
                    ${$this->xbd->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x186b}}} = ${$this->xbd->x806->{$this->xc2->x806->x95d}}->{$this->x1c->x806->xf2d}()
                        ->{$this->xc2->x806->xf3e}($this->resource->{$this->xbd->x806->xe8f}("c\141\164\141\x6c\x6f\147\137\160r\157d\x75\x63\x74_r\145l\x61\x74io\x6e"), ["p\x61re\156\164\x5f\x69d", "\143h\x69l\x64\137\x69\x64"])
                        ->{$this->x1c->x806->xfb8}("\x63\x68\x69\154\144\x5f\151d\x20\111\x4e \x28\x3f)", ${$this->xbd->x806->{$this->xbd->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->xa1b}}}}});
                }



                ${$this->xc2->x80e->{$this->xc2->x80e->x1951}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->x967}}}}}->{$this->x1c->x806->xf05}(${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x186f}}}}});
                while (${$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa94}}} = ${$this->xc2->x80e->x194d}->{$this->x1c->x806->x10e2}()) {
                    ${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->xc2->x80e->x1963}}}}} = ${$this->xbd->x806->xa91}["\143\150\x69\x6cd_\151d"];
                    if (!isset(${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xbd->x80e->{$this->x1c->x80e->x195d}}][${$this->xc2->x806->xaf5}])) {
                        ${$this->xc2->x80e->x18e8}[${$this->xbd->x806->xaa2}][${$this->xc2->x806->{$this->xbd->x806->{$this->xbd->x806->xafd}}}] = [];
                    }
                    ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xbd->x806->xaa2}][${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xafe}}}}][] = (int) ${$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa94}}}["\x70\141r\x65\x6e\x74\x5fi\x64"];


                                        ${$this->x1c->x80e->x19c8} = ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}}["pa\x72\145n\x74\137i\144"];
                    ${$this->xbd->x806->xb0b} = ${$this->x1c->x80e->x1808}->{$this->x1c->x806->xf2d}()
                        ->{$this->xc2->x806->xf3e}(${$this->xc2->x806->{$this->xbd->x806->x914}}, ${$this->x1c->x806->{$this->x1c->x806->xaf1}})
                        ->{$this->x1c->x806->xfb8}("\x70\162\157\x64\165\x63\164\137\151\x64 \111\116\x20\50\77)", ${$this->xc2->x806->{$this->x1c->x806->xb03}})
                        ->{$this->x1c->x806->xfb8}("\163\164\x6f\x72\145\137\151\x64\x20\75\x20\x3f", ${$this->xc2->x80e->x17bd})
                        ->{$this->x1c->x806->xfb8}("\x63\141\164\145\x67\157r\171_\x69\144\40\76\40\61");                                         if (!$this->{$this->x1c->x806->{$this->xbd->x806->x829}}->{$this->xc2->x806->xf26}("A\155\x61\x73t\171\x5f\x53\x68\157\160\x62\x79") && !$this->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->x82b}}}->{$this->xc2->x806->xf26}("\101ma\x73\x74\x79\x5f\123\x68o\160\x62\x79B\162an\x64")) {
                        ${$this->xbd->x806->xb0b}->{$this->x1c->x806->xfb8}("\x63\141te\147\x6fr\x79\137\x69\x64\x20\41\x3d \77", ${$this->xc2->x806->x92d}->{$this->xc2->x806->x1227}());                     }

                    ${$this->xbd->x806->xb0b}->{$this->x1c->x806->x1235}("\160r\x6f\x64\x75\x63\164\x5fi\x64");

                    ${$this->xbd->x806->xb13} = ${$this->xc2->x80e->{$this->xbd->x80e->x180b}}->{$this->x1c->x806->xf05}(${$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xb0f}}});
                    ${$this->xbd->x806->{$this->xc2->x806->{$this->xbd->x806->xb21}}} = ${$this->xbd->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xb1c}}}}->{$this->x1c->x806->x10e2}();
                    if (${$this->xbd->x806->{$this->xc2->x806->{$this->xbd->x806->xb21}}} != null) {
                        ${$this->xbd->x806->{$this->xc2->x806->xa1e}}[${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->xc2->x80e->x1963}}}}}][\Wyomind\Elasticsearch\Helper\Config::PRODUCT_CATEGORIES_PARENT_ID] = $x534($x535($x482($x606(',', ${$this->xbd->x80e->{$this->xc2->x80e->x19e5}}["\x63\x61\x74\x65\x67\x6fr\x79\x5f\x69\144\x73"]))));
                    }
                }


                
                ${$this->xc2->x80e->x19bd} = \Wyomind\Elasticsearch\Helper\Config::PRODUCT_CATEGORIES;
                ${$this->x1c->x806->{$this->xc2->x806->x9ba}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->xbd->x806->x95f}}}->{$this->x1c->x806->xf2d}()
                    ->{$this->xc2->x806->xf3e}(${$this->xc2->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x17d1}}}}, ${$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->xaf4}}})
                    ->{$this->x1c->x806->xfb8}("\160\162\157\x64\165\143\x74_id\x20\x49\116 \x28?\x29", ${$this->xbd->x80e->x18dc})
                    ->{$this->x1c->x806->xfb8}("s\164\157\x72\145\137id\x20=\40\x3f", ${$this->xbd->x806->x8fc})
                    ->{$this->x1c->x806->xfb8}("c\141\164\x65\x67\x6f\162\x79_\x69\x64 >\x20\61");                                 if (!$this->{$this->x1c->x806->{$this->xbd->x806->x829}}->{$this->xc2->x806->xf26}("\101\x6da\163\164\x79_\x53h\157\x70b\171") && !$this->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->x82b}}}->{$this->xc2->x806->xf26}("\x41\155\141\163\x74y\137\x53\150o\x70b\x79Br\x61\x6e\144")) {
                    ${$this->xbd->x80e->{$this->x1c->x80e->x1869}}->{$this->x1c->x806->xfb8}("c\x61\x74\x65g\157r\171_id\40!\75\x20\77", ${$this->x1c->x80e->x17e5}->{$this->xc2->x806->x1227}());                 }

                ${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x186f}}}}}->{$this->x1c->x806->x1235}("\x70r\157du\143t_\x69d");

                ${$this->xc2->x80e->{$this->xc2->x80e->x1951}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->x967}}}}}->{$this->x1c->x806->xf05}(${$this->xbd->x80e->x1866});

                while (${$this->xc2->x80e->{$this->xbd->x80e->x1953}} = ${$this->xc2->x80e->x194d}->{$this->x1c->x806->x10e2}()) {
                    ${$this->xbd->x80e->{$this->xbd->x80e->x19f0}} = $x606(",", ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}}["\x63a\x74e\147\x6f\x72\x79\137\x69d\x73"]);
                    if ($this->{$this->xbd->x806->{$this->xc2->x806->x84f}} != null) {
                        ${$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x19f9}}}}[] = $this->{$this->xbd->x806->{$this->xc2->x806->{$this->xc2->x806->{$this->xc2->x806->x857}}}};
                        ${$this->xbd->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x19f4}}} = $x535(${$this->xbd->x80e->{$this->xbd->x80e->x19f0}});
                    }

                    if (empty(${$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x19f9}}}})) {
                        continue;
                    }
                    ${$this->xbd->x806->xaa2} = ${$this->x1c->x806->{$this->xbd->x806->xa93}}["\160\x72\x6f\144u\143\x74\137\x69\x64"];
                    if (!isset(${$this->xbd->x806->{$this->xc2->x806->xa1e}}[${$this->xc2->x806->{$this->xc2->x806->xaa3}}][${$this->xc2->x806->xaf5}])) {
                        ${$this->xc2->x80e->x18e8}[${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x1962}}}}][${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xafe}}}}] = [];
                        ${$this->xc2->x80e->x18e8}[${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->xc2->x80e->x1963}}}}}][${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x19c3}}} . "\x5f\x69\144\x73"] = [];
                    }
                    foreach (${$this->xbd->x806->xb26} as ${$this->xc2->x806->{$this->x1c->x806->xb32}}) {
                        if (${$this->x1c->x806->xb37} = ${$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x1817}}}}->{$this->xbd->x806->x1315}(${$this->xc2->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x1a02}}})) {
                            
                            ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->x1c->x80e->x1a11}}}}->{$this->xbd->x806->x104f}(${$this->xc2->x80e->x17bd});
                            ${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->x1c->x80e->{$this->xbd->x80e->x1a24}}}}} = $this->categoryHelper->{$this->xc2->x806->x132c}(${$this->xbd->x806->{$this->xc2->x806->xb38}});
                            if (${$this->xbd->x806->xb3d} != "") {
                                ${$this->x1c->x806->xa1c}[${$this->xbd->x80e->{$this->x1c->x80e->x195d}}][${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x19c3}}}][] = ${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x1a1d}}};
                            }
                            ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xbd->x80e->{$this->x1c->x80e->x195d}}][${$this->x1c->x80e->{$this->x1c->x80e->x19c2}} . "\x5fid\x73"][] = ${$this->x1c->x80e->x19fe};
                        }
                    }
                    ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xbd->x80e->{$this->x1c->x80e->{$this->x1c->x80e->x195e}}}][${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x19c3}}}] = $x534($x535(${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xbd->x80e->{$this->x1c->x80e->x195d}}][${$this->xc2->x806->xaf5}]));
                }

                                ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x19c3}}} = \Wyomind\Elasticsearch\Helper\Config::PRODUCT_PRICES;
                ${$this->x1c->x806->{$this->x1c->x806->xb4c}} = ${$this->xbd->x806->{$this->xc2->x806->x95d}}->{$this->xbd->x806->x133c}(["\x70\162\x69c\x65s\56\x6d\x69\156\137p\162\x69c\x65", "p\x72\x69c\x65\163.t\151\145\162\137\160ri\143\x65"]);
                ${$this->xbd->x806->xb51} = ${$this->xbd->x806->{$this->xc2->x806->{$this->xbd->x806->x95f}}}->{$this->x1c->x806->x1095}("\160\x72ic\x65\163\x2e\x74\x69\x65\x72\x5f\x70\x72\151\x63\145\x20I\123\40\116O\x54 N\x55\114\x4c", ${$this->x1c->x806->{$this->x1c->x806->xb4c}}, "p\162\x69c\x65\163\x2e\155\151\156\137pric\x65");
                ${$this->x1c->x80e->x1a40} = [
                    "\x65\x6e\164\151ty\137\x69d", "\x70\x72\x69\x63\145", "\x66i\156a\x6c_p\162\151\x63\x65",
                    "\155in\x69\x6d\141\154\137pr\x69c\145" => ${$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->x1c->x806->xb5b}}}},
                    "m\151n_p\x72\x69\143\145", "ma\170\137\x70\x72i\x63e", "t\x69e\x72\137\160\162\151\x63\145"
                ];
                ${$this->xbd->x80e->x1866} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->x967}}}}}->{$this->x1c->x806->xf2d}()
                    ->{$this->xc2->x806->xf3e}(["\x70\x72\x69c\x65\x73" => $this->resource->{$this->xbd->x806->xe8f}("c\x61t\141l\157\x67\137p\162\157\x64\x75\x63\x74_\151\156\x64e\x78\137\x70\162\x69\x63\145")], ${$this->xc2->x806->{$this->x1c->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->xb69}}}}})
                    ->{$this->x1c->x806->xfb8}("\x70\162ice\163\x2e\145n\x74ity\137id IN\x20\50\x3f)", ${$this->xbd->x80e->x18dc})
                    ->{$this->x1c->x806->xfb8}("\160\x72\x69c\145s\56\167\145\x62\x73\x69\164\145\137\151d\40\x3d\40?", ${$this->xc2->x80e->{$this->xbd->x80e->x17e9}}->{$this->x1c->x806->xf5c}())
                    ->{$this->x1c->x806->xfb8}("\x70\162ic\145\x73\x2e\143u\163\164o\155er_\x67\x72\x6f\165\x70\137id\x20=\x20\x3f", ${$this->xbd->x806->{$this->xbd->x806->x970}});
                ${$this->x1c->x806->{$this->xc2->x806->x9ba}}->{$this->x1c->x806->x1074}(["\x70\162ic\145\137\x72\165l\x65" => $this->resource->{$this->xbd->x806->xe8f}("\x63\x61\x74\141\x6co\147\x72ule\x5f\x70ro\144\165\x63t_\160r\x69\x63e")], "p\162\x69\x63\145\x5f\x72\165\x6ce\56p\162od\x75\143t\137\x69d\x20= p\162\151\143e\163\56\145\x6e\164\151\164\171_\x69d A\116\104\40" . ${$this->xbd->x806->{$this->xc2->x806->x95d}}->{$this->xc2->x806->xf55}("\160\x72i\x63\145_\x72\x75\154e.w\145\142\163\x69te\137\151\x64\x20\x3d\40?", ${$this->xc2->x806->x92d}->{$this->x1c->x806->xf5c}()) . "\x20\101\116\104\40" . ${$this->xc2->x80e->{$this->xbd->x80e->x180b}}->{$this->xc2->x806->xf55}("p\162\x69\x63\x65\137\x72u\x6ce.c\x75\x73t\x6fm\145\162\x5fgr\157up_\x69\x64\x20=\x20?", ${$this->x1c->x80e->x181f}), ["\x72\x75le\x5fpr\x69\143e"]);

                ${$this->xbd->x806->{$this->xc2->x806->xa8c}} = ${$this->x1c->x80e->x1808}->{$this->x1c->x806->xf05}(${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x186f}}}}});
                while (${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}} = ${$this->xc2->x80e->x194d}->{$this->x1c->x806->x10e2}()) {
                    ${$this->xbd->x80e->x1958} = ${$this->x1c->x806->{$this->xbd->x806->xa93}}["e\156t\151\x74y\x5f\151d"];
                    unset(${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa99}}}}["\145\x6e\164i\164\171\137\x69d"]);

                                        $x597(${$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa94}}}, array('\Wyomind\Elasticsearch\Model\Indexer\Product', 'convertPrice'));

                    if (${$this->xbd->x806->xa91}['final_price'] > ${$this->xc2->x80e->{$this->xbd->x80e->x1953}}['rule_price'] && ${$this->xbd->x80e->x1952}['rule_price'] != 0) {
                        ${$this->xbd->x806->xa91}['final_price'] = ${$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa94}}}['rule_price'];
                    }

                                        try {
                        if (isset(${$this->xc2->x80e->x18e8}[${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x1962}}}}]['type_id']) && ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xc2->x806->{$this->xc2->x806->xaa3}}]['type_id'] == "\143\x6f\x6ef\x69\147\x75ra\142l\x65") {
                            if (${$this->xc2->x80e->{$this->xbd->x80e->x1953}}['final_price'] == 0) {
                                ${$this->xbd->x806->xa91}['final_price'] = ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}}['min_price'];
                            }
                            if (${$this->xbd->x80e->x1952}['price'] == 0) {
                                ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa99}}}}['price'] = ${$this->x1c->x806->{$this->xbd->x806->xa93}}['final_price'];
                            }
                        }
                    } catch (\Exception $e) {
                                            }

                    ${$this->xbd->x806->{$this->xc2->x806->xa1e}}[${$this->xbd->x80e->x1958}][${$this->xc2->x806->xaf5}] = ${$this->xbd->x80e->x1952};
                }

                                ${$this->xc2->x80e->x19bd} = \Wyomind\Elasticsearch\Helper\Config::PRODUCT_URL;
                ${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x186f}}}}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->x964}}}}->{$this->x1c->x806->xf2d}()
                    ->{$this->xc2->x806->xf3e}($this->resource->{$this->xbd->x806->xe8f}("u\x72\x6c\137\x72\x65w\162\x69t\145"), [
                        "pr\157\144\165\x63t\x5f\x69\144" => "\x65n\164\151\x74\171\x5fi\144",
                        "\162\145qu\x65\x73t\x5f\160\x61th" => "gr\x6f\165\x70\137\x63\157\156\143\141\x74\x28r\145q\x75\145\163t\x5f\x70\141\x74\x68\x29",
                        "\x6de\164\x61\144\x61ta" => "g\x72\x6fup_\143\x6f\x6e\143\x61\164\50\x49\x46N\x55\x4c\x4c\50\x6d\x65t\141\x64\x61\164\141\54\40\x27\x27)\x29"
                    ])
                    ->{$this->x1c->x806->xfb8}("\x73\164\x6f\162e\x5f\x69\x64 \75\40?", ${$this->x1c->x806->{$this->xc2->x806->x8fd}})
                    ->{$this->x1c->x806->xfb8}("\145n\x74it\171_\164\171pe\x20\75\40\77", UrlRewrite::ENTITY_TYPE_PRODUCT)
                                        ->{$this->x1c->x806->xfb8}("r\145dire\143t_\164y\160e\x20\x3d\x20\x30")
                    ->{$this->x1c->x806->xfb8}("en\164it\x79\137\x69\144\40\x49N\x20(\x3f)", ${$this->xbd->x806->xa0e})
                    ->{$this->x1c->x806->x1235}("en\x74\151\x74y\137id");

                ${$this->xc2->x80e->{$this->xc2->x80e->x1951}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->x967}}}}}->{$this->x1c->x806->xf05}(${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x186f}}}}});
                $baseUrl = ${$this->xc2->x806->x92d}->{$this->x1c->x806->x14b2}(\Magento\Framework\UrlInterface::URL_TYPE_LINK, ${$this->x1c->x80e->x17e5}->{$this->xbd->x806->x14c4}());
                $baseUrl = $x5f0(['/magento/', '/n98-magerun2/'], ['/', '/'], $baseUrl);

                while (${$this->xbd->x80e->x1952} = ${$this->xbd->x806->xa8a}->{$this->x1c->x806->x10e2}()) {
                    ${$this->xc2->x806->{$this->xc2->x806->xaa3}} = ${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa99}}}}["p\x72o\x64u\143\x74_\151\x64"];
                    ${$this->xc2->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x1a69}}} = $x606(',', ${$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa94}}}['metadata']);
                    $requestPaths = $x606(',', ${$this->xbd->x806->xa91}['request_path']);
                    $nbPaths = $x76b($requestPaths);
                    for (${$this->x1c->x80e->{$this->x1c->x80e->{$this->xbd->x80e->x18d5}}} = 0; ${$this->xc2->x806->xa0a} < $nbPaths; ${$this->xc2->x806->{$this->x1c->x806->xa0b}}++) {
                        if (!isset(${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xb7c}}}[${$this->xc2->x806->{$this->x1c->x806->{$this->x1c->x806->xa0c}}}]) || ${$this->xbd->x806->xb7a}[${$this->x1c->x80e->{$this->x1c->x80e->{$this->xbd->x80e->x18d5}}}] == "") {
                            ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xbd->x80e->{$this->x1c->x80e->{$this->x1c->x80e->x195e}}}][\Wyomind\Elasticsearch\Helper\Config::PRODUCT_URL] = $baseUrl . $requestPaths[${$this->x1c->x80e->{$this->x1c->x80e->{$this->xbd->x80e->x18d5}}}];
                            unset($requestPaths[${$this->x1c->x80e->{$this->x1c->x80e->x18d4}}]);
                        }
                    }
                    $x63b($requestPaths, array('\Wyomind\Elasticsearch\Model\Indexer\Product', 'compareRequestPaths'));
                    if ($x76b($requestPaths) > 0) {
                        ${$this->x1c->x80e->{$this->xbd->x80e->x18ec}}[${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x1962}}}}][\Wyomind\Elasticsearch\Helper\Config::PRODUCT_SHORTEST_URL] = $baseUrl . $requestPaths[0];
                        ${$this->xbd->x806->{$this->xc2->x806->xa1e}}[${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->x1c->x806->xaae}}}}}][\Wyomind\Elasticsearch\Helper\Config::PRODUCT_LONGEST_URL] = $baseUrl . $x658($requestPaths);
                    }
                }
                $configuable = $this->objectManager->{$this->xbd->x806->x14e1}('\Magento\ConfigurableProduct\Model\Product\Type\Configurable');
                foreach (${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}} as ${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->x1c->x806->xaae}}}}} => ${$this->xbd->x80e->{$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x1aa6}}}}}) {
                                        if (isset(${$this->xbd->x80e->{$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x1aa6}}}}}['type_id']) && ${$this->xbd->x80e->{$this->x1c->x80e->{$this->xc2->x80e->x1aa0}}}['type_id'] == "c\x6f\156\x66\151\x67u\162\x61\x62\154e") {
                        $product = $this->objectManager->{$this->xbd->x806->x14e1}('Magento\Catalog\Model\Product')->{$this->xbd->x806->x14f9}(${$this->xbd->x806->xaa2});
                        $product->{$this->xbd->x806->x104f}(${$this->xc2->x80e->x17bd});
                        ${$this->xbd->x806->xbba} = $configuable->{$this->x1c->x806->x1514}($product);
                        ${$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->{$this->xc2->x806->xbca}}}} = $configuable->{$this->xbd->x806->x1526}($product);
                        if (${$this->x1c->x80e->{$this->xc2->x80e->{$this->x1c->x80e->x1ac2}}} != null) {
                            foreach (${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x1ac7}}}} as ${$this->x1c->x806->{$this->xc2->x806->xa55}}) {
                                ${$this->xc2->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xbe2}}}}} = [];
                                ${$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->xc2->x806->xabf}}}} = ${$this->x1c->x80e->{$this->xc2->x80e->{$this->xbd->x80e->x191d}}}->{$this->xbd->x806->x1041}();
                                foreach (${$this->xc2->x806->{$this->xc2->x806->xbbf}} as ${$this->xbd->x806->{$this->x1c->x806->{$this->xbd->x806->{$this->xbd->x806->xbec}}}}) {
                                    ${$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->xbdb}}}[] = ${$this->xc2->x80e->{$this->xbd->x80e->x1ae0}}->{$this->x1c->x806->x1559}(${$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xaba}}});
                                }
                                ${$this->x1c->x80e->{$this->xbd->x80e->x18ec}}[${$this->xbd->x80e->x1958}][${$this->xbd->x806->{$this->x1c->x806->xab8}} . '_ids'] = ${$this->xc2->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xbe2}}}}};
                            }
                        }
                    }
                }

                                if ($this->indexerHelper->{$this->xc2->x806->xf65}(${$this->xbd->x806->{$this->x1c->x806->x92e}})) {
                    ${$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->x9c3}}} = $this->indexerHelper->{$this->xbd->x806->xf75}(${$this->xc2->x806->x92d});
                    ${$this->xc2->x80e->{$this->xc2->x80e->{$this->x1c->x80e->x1882}}} = [
                        "\163\164\157\x63\153\56\165\x73\145\x5f\143on\x66\x69\147_\x6d\141\x6e\141\x67\145\x5fst\157\x63\x6b = \x30\x20\x41N\104\40\x73t\x6f\143\x6b.\155\141\x6ea\x67\x65\137\163\164ock =\40\61 A\x4eD \x73\x74\157\143\153.\x69\163\137\151\156_s\164o\x63k\40\75\40\61",
                        "\x73\164\x6f\x63\x6b\56u\x73\145_c\157n\146\x69\147\x5f\155\x61\156a\147\145_\x73\x74oc\153\x20\x3d \x30 \x41N\x44 s\x74\x6fc\x6b.\155\141\x6eag\145_\163\164\157c\x6b\40\x3d \x30",
                    ];
                    if (${$this->x1c->x806->{$this->x1c->x806->x9c0}}) {
                        ${$this->xc2->x80e->{$this->xc2->x80e->{$this->x1c->x80e->x1882}}}[] = "\x73\x74\157c\153\56u\x73\145\x5f\143\x6f\156\146\151\x67\137\155an\141\x67\x65_\x73\x74\x6f\x63\x6b\40=\40\61 \101\x4e\x44 \x73\164\157\143k\56i\x73\x5fi\156\137s\164\x6fck =\x20\61";
                    } else {
                        ${$this->x1c->x806->{$this->xbd->x806->x9c9}}[] = "\x73\x74oc\153\56\x75se\x5f\x63\x6f\156\146\x69\x67\137\155\x61\x6e\x61ge\137st\157ck\40\x3d \61";
                    }
                    ${$this->xc2->x80e->{$this->xc2->x80e->x188f}} = "((" . $x6c2("\x29\40\x4f\x52\x20\50", ${$this->xc2->x80e->x187c}) . "\51)";
                    ${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x186f}}}}} = ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->{$this->xc2->x806->x967}}}}}->{$this->x1c->x806->xf2d}()->{$this->xc2->x806->xf3e}(["\x65" => ${$this->xbd->x80e->x17ff}], "\x65\x6e\164\x69\x74\171_\x69\144");
                    ${$this->x1c->x806->{$this->xc2->x806->x9ba}}->{$this->x1c->x806->x1595}(["\x73\164\157\x63\153" => ${$this->x1c->x806->{$this->xbd->x806->{$this->xc2->x806->x9d2}}}]);
                    ${$this->x1c->x806->{$this->xc2->x806->x9ba}}->join(["\x70\162o\144uct\x5f\x77ebsi\x74\x65" => $this->resource->{$this->xbd->x806->xe8f}("\x63a\x74\x61\154\x6f\147\x5f\160\162\157\x64uc\x74\x5f\x77eb\163\151t\145")], "\160\x72\x6f\144uc\164_w\145\x62\x73i\164\145.p\x72\157du\x63\x74_\151d \x3d\x20\145\56e\156\164\x69\164\171\137\151\144\x20\101\116\x44\x20" . ${$this->xbd->x806->{$this->xc2->x806->x95d}}->{$this->xc2->x806->xf55}("\x70r\x6f\144u\x63t_\x77\145\142s\151t\x65\x2e\167\145\142\163\x69\x74\x65\137\151\144\x20\x3d\40\x3f", ${$this->x1c->x80e->x17e5}->{$this->x1c->x806->xf5c}()), []);
                    ${$this->xbd->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x186b}}}->join(["\x73t\x6fck" => $this->resource->{$this->xbd->x806->xe8f}("\x63\141t\141\x6coginv\145\156\164\x6f\162y\137\x73\164o\x63k\137\151\x74\x65\155")], "\x28\x73\x74\x6f\143\153\x2ep\162od\165ct\x5f\151\x64\x20\x3d\x20\145\x2e\145\156\164\x69ty\137i\x64\51", []);
                    ${$this->x1c->x806->{$this->xc2->x806->x9ba}}->{$this->x1c->x806->xfb8}("\x65\156tit\171\137\151\x64\x20\111N\x20(\x3f\51", ${$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->x18e4}}});
                    ${$this->xbd->x806->xa8a} = ${$this->xc2->x80e->{$this->xbd->x80e->x180b}}->{$this->x1c->x806->xf05}(${$this->xbd->x80e->{$this->xbd->x80e->{$this->xbd->x80e->{$this->xc2->x80e->{$this->xc2->x80e->x186f}}}}});

                    while (${$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->{$this->x1c->x806->xa9e}}}}} = ${$this->xbd->x806->{$this->xc2->x806->xa8c}}->{$this->x1c->x806->x10e2}()) {
                        ${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->x1c->x806->xaa9}}}} = ${$this->xc2->x80e->{$this->xbd->x80e->x1953}}["\x65\x6e\164\x69\x74y\137\151\144"];
                        ${$this->x1c->x806->xa1c}[${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->xaa8}}}]['stock_status_ids'] = ${$this->x1c->x806->{$this->x1c->x806->{$this->xbd->x806->xa94}}}['stock'] == 1 ? "\61" : "\62";
                    }
                }


                

                foreach ($x70e(${$this->x1c->x80e->{$this->xbd->x80e->x18ec}}) as ${$this->x1c->x80e->{$this->x1c->x80e->x19c2}}) {
                    if (!isset(${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x19c3}}}]['product_weight'])) {
                        ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xc2->x806->{$this->xbd->x806->xaf8}}]['product_weight'] = 1;
                    }

                    if (isset(${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xc2->x806->xaf5}]["\x76\x69\163i\142\x69l\x69t\x79"]) && ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x19c3}}}]["\x76\x69\x73\151\x62\151lit\x79"] > 2 && !isset(${$this->x1c->x806->xa1c}[${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xafe}}}}][\Wyomind\Elasticsearch\Helper\Config::PRODUCT_URL])) {
                        ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}}[${$this->xc2->x806->xaf5}][\Wyomind\Elasticsearch\Helper\Config::PRODUCT_URL] = $baseUrl . "\143a\x74\141l\x6f\147\x2f\x70r\157du\x63\x74/\x76\x69\x65\x77\57\151d\57" . ${$this->xc2->x806->{$this->xbd->x806->xaf8}};
                        ${$this->xc2->x80e->x18e8}[${$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->{$this->xc2->x806->xafe}}}}][\Wyomind\Elasticsearch\Helper\Config::PRODUCT_SHORTEST_URL] = $baseUrl . "\143a\164\141\154\x6fg/pr\x6f\x64\x75\x63\164\x2f\x76\151\x65\x77\57\151\x64/" . ${$this->xc2->x806->xaf5};
                        ${$this->x1c->x80e->{$this->xbd->x80e->x18ec}}[${$this->xc2->x80e->x19bd}][\Wyomind\Elasticsearch\Helper\Config::PRODUCT_LONGEST_URL] = $baseUrl . "\143a\x74\x61\x6c\x6f\147\57\160\162\157\144\165\x63t\57\166ie\167\x2f\151\144\x2f" . ${$this->xc2->x806->xaf5};
                    }
                }

                yield ${$this->x1c->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x18ee}}};
            }

            $this->{$this->x1c->x806->xe6a}("\74in\x66\157\76" . $x76b(${$this->xbd->x806->x904}) . "\40\160\162od\x75\x63\x74\163\40\151n\x64\x65\x78\x65d\74\57\x69\x6e\146\x6f>");
            $this->{$this->x1c->x806->xe6a}("");
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->{$this->xbd->x806->x161f}($e->{$this->xbd->x806->x1629}());
        }
        $this->eventManager->{$this->xbd->x806->xe5a}('wyomind_elasticsearch_product_export_after', ['store_id' => ${$this->x1c->x806->{$this->xc2->x806->x8fd}}, 'ids' => ${$this->xbd->x806->x904}]);
    }

    public function compareRequestPaths(
    $x78e,
        $x799
    )
    {$x793 = $this->xc2->x80e->{$this->x1c->x80e->{$this->x1c->x80e->x1cd2}};$x797 = $this->xbd->x80e->{$this->xc2->x80e->x1cd6};
        return ($x793($x797('/', ${$this->xc2->x806->{$this->xbd->x806->{$this->xc2->x806->{$this->xbd->x806->{$this->x1c->x806->xbfc}}}}})) < $x793($x797('/', ${$this->xc2->x806->{$this->x1c->x806->{$this->xc2->x806->xc07}}}))) ? -1 : 1;
    }

    public function convertPrice(&$x7af)
    {$x7a3 = $this->xc2->x80e->{$this->xbd->x80e->{$this->xbd->x80e->x1ceb}};
        if ($x7a3(${$this->xc2->x806->xc0f})) {
            ${$this->xc2->x80e->x1b0d} = (float) ${$this->xc2->x806->xc0f};
        }
    }

    
    public function getCategoryNames($x7ce)
    {
        ${$this->xc2->x80e->{$this->x1c->x80e->x1b27}} = $this->resource->{$this->x1c->x806->xefb}();
        ${$this->xc2->x806->{$this->xc2->x806->{$this->x1c->x806->xc3f}}} = $this->entityFactory->{$this->xbd->x806->x14e1}()->{$this->x1c->x806->x1659}(\Magento\Catalog\Model\Category::ENTITY);
        ${$this->x1c->x806->{$this->x1c->x806->xc45}} = ${$this->xbd->x806->xc39}->{$this->xbd->x806->xf94}("n\141\155\145")->{$this->xbd->x806->xfa2}();
        ${$this->xc2->x806->{$this->xc2->x806->{$this->x1c->x806->xc56}}} = ${$this->xc2->x80e->{$this->xbd->x80e->{$this->x1c->x80e->x1b2a}}}->{$this->x1c->x806->xf2d}()
            ->{$this->xc2->x806->xf3e}($this->resource->{$this->xbd->x806->xe8f}("\143\141\x74\x61\x6c\157\147\x5f\x63a\x74\145g\x6fr\171\137\145\156\x74\151\x74\171_\x76\x61\162c\150ar"), ["e\156\x74\x69\164\171\137\151d", "\x76a\x6c\x75e"])
            ->{$this->x1c->x806->xfb8}("a\164\x74\162i\x62\x75\x74\145_\151d\40\75\x20\x3f", ${$this->x1c->x806->{$this->xc2->x806->{$this->xbd->x806->xc49}}})             ->{$this->x1c->x806->xfb8}("\x73t\157\x72\x65_id\40\x49\116\40\x28\77\51", [0, ${$this->xbd->x806->{$this->xc2->x806->{$this->x1c->x806->{$this->xbd->x806->{$this->x1c->x806->xc2e}}}}}])             ->{$this->x1c->x806->x16c7}(["e\x6e\164i\x74\171\137\x69d\40\101\123C", "stor\x65\x5fid \101\123C"]); 
        return ${$this->xbd->x806->{$this->xbd->x806->xc32}}->{$this->xc2->x806->x16d5}(${$this->xc2->x806->{$this->x1c->x806->xc53}});
    }

}
