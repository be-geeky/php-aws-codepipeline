/**
 * Copyright © 2016 Wyomind. All rights reserved.
 * https://www.wyomind.com
 */
var config = {
    map: {
        '*': {
            wyoSearch: 'Wyomind_Elasticsearch/form-mini'
        }
    }
};