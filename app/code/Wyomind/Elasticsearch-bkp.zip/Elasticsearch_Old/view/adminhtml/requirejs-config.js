var config = {
    paths: {
        "Wyomind_Elasticsearch_Jsonview": "Wyomind_Elasticsearch/js/jquery.jsonview.min"
    }
};