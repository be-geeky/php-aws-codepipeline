<?php

/**
 * Copyright © 2016 Wyomind. All rights reserved.
 * See LICENSE.txt for license details.
 */

include dirname(__DIR__) . DIRECTORY_SEPARATOR . 'autocomplete.php';
